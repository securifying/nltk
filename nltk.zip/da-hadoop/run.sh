#!/bin/sh 

hadoop jar WordCount.jar wordcount.Runner mock.txt output

